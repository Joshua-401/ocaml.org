# DeepSEA Ethereum

This branch contains the Ethereum version of DeepSEA.

DeepSEA is a high-level language to describe ethereum contracts.
DeepSEA compiles to Coq, so that facts can be proved about the contract.
DeepSEA also compiles to EVM bytecode, so that the contract code can be run on the Ethereum blockchain.

## Setup

### Docker

1. Install [Docker](https://www.docker.com)
2. Allow Docker to present GUI windows. These instructions are not cross-platform. For mac: follow [these instructions](https://medium.com/@mreichelt/how-to-show-x11-windows-within-docker-on-mac-50759f4b65cb).
    1. Install [XQuartz](https://www.xquartz.org/), and reboot computer to complete installation.
    2. Enable "Allow connections from network clients" in XQuartz preferences, and restart XQuartz to finalize setting.
    3. Run `xhost +` to allow all incoming connections.
3. Open a shell, and `cd` to the root of this repo.
4. Run `./coqshell` to open a shell into a Docker container running coq and coqide.

### Nix

Install [nix](https://nixos.org/nix/):
```sh
curl https://nixos.org/nix/install | sh
```
Start a nix shell in the root directory of this repo:
```sh
nix-shell -I nixpkgs=channel:nixpkgs-unstable
```
(We need the unstable channel for coq version `8.9.0`.)

### Legacy

Otherwise, install Coq version `8.9.0`. Note this was a recent migration so there are still some loose ends: see the TODO in lib/IndexedMaps.v

## Usage

### Compiling the example contract
```sh
make token-extraction
./contracts/token/extraction/extract
```

### Compiling MiniC to EVM commands

MiniC exists only in abstract syntax tree (AST) form. Some of the files in `backend/examples` are Coq files that define programs in MiniC AST.

Run one of the examples like backend/examples/recursion.v in an interactive proof checker.
Note that the last line does an "Extraction" that turns Coq code into ocaml, placed in the backend/extraction directory.
Then from the backend/extraction directory run `make`. This generates an executable `extract`. Run it, and it will print out the EVM code: `backend/extraction/extract > backend/examples/recursion.evm`.

Currently extracted executable `extract` will print the `.evm` code in a pseudo-assembly, similar to the solidity compiler's assembly output. The simulator written in Python reads and executes this pseudo-assembly code.

To make the code executable on the blockchain, replace `print_compiled` with `print_compiled_bytes` in `Tester.ml`.

## Code Layout

- cclib: Some supporting code stolen from CompCert, in order to make the project compile independently of CompCert.
- Edsger: the "front-end" part of the compiler, written in OCaml. This contains a parser, typechecker, and the file coqgen.ml which writes out a set of coq files, which contain (among other things) the AST of the type-annotated program.
- lib: Some helper methods.
- core: The "middle-end" of the compiler. Although it is currently commented out in this branch, the file SynthesisStmt.v contains the central part of the compiler: functions to generate miniC code and Gallina specifications.
- backend: a compiler from MiniC to EVM. It has a separate readme file.
- ethereum: an experiment in how to reason about a simple payment channel contract. Does not currently use DeepSEA, although it has the start of a DeepSEA implementation of the same contract.
- evm-spec: Currently unused. Some files from when we were looking at Yoichi Hirai's EVM formalization.

## Troubleshooting

### Inconsistent assumptions

"... Inconsistent assumptions over ..." error: this indicates that some dependencies have been compiled for different systems, or that they were compiled in the wrong order. Run `make clean` and then `make` to re-run the full compilation. If this error persists, there are probably some files missing from `_CoqProject`.

### Cannot find a physical path bound

The `Require Import` statements might not work, due to path-binding errors.

They work in Coqide, when `coqide backend/phase/<whatever>` is run from the root of the repo, so Coqide is getting the import paths from `_CoqProject`.
In ProofGeneral they are supposed to work, but they don't for me.
In case your IDE does not recognize the `_CoqProject` file, you can do interactive proof-checking by pasting this at the top of any file open in the IDE:

```
Cd "/absolute/path/to/DeepSEA".
Add LoadPath "core" as DeepSpec.core.
Add LoadPath "lib" as DeepSpec.lib.
Add LoadPath "lib/Monad" as DeepSpec.lib.Monad.
Add LoadPath "cclib" as cclib.
Add LoadPath "backend" as backend.
Add LoadPath "ethereum" as ethereum.
```

## Building

To build the executable:

1. Run `make` to compile the Coq parts.
    - Make sure your `coqc --version` is 8.9.0.
    - `opam pin add coq 8.9.0` to downgrade.
2. Open backend/Extract.v in your interactive Coq system (CoqIDE or ProofGeneral) and run it to generate ml files in backend/extraction/.
    - CoqIDE can be installed with `opam install coqide`
    - and run with `coqide`.
3. Run `make edsger` to run ocamlbuild and build the OCaml parts.
    - You may get an error if you have any compiled files in Edsger, such as  `*.o`, `*.cmi`, `*.cmx`, `lexer.ml`, `parser.ml`, or `parser.mli`. Remove these files and try again.
