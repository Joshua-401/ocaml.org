node2nix --nodejs-10 -i packages.json
