This directory contains files copied from CompCert, but which are not directly
related to the C language.
