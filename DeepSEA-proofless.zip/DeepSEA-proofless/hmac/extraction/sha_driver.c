#include <stdio.h>
#include <stdlib.h>
#include <string.h>

extern void SHA256_sha256(void);

extern unsigned int __builtin_read32_reversed(const unsigned int * ptr);
extern unsigned int K256_data[];
extern unsigned int SHA256Word_H[];

unsigned char message[64] = "The quick brown fox jumps over the lazy dog";

void pad(void) {
  int len = strlen(message);
  message[len] = 0x80;

  int len8 = len * 8;
  message[62] = (len8 >> 8) & 0xff;
  message[63] = len8        & 0xff;

}

unsigned int File_read(int offset)  {
  unsigned val =
          ( (message[4*offset] << 24)
 	  | (message[4*offset+1] << 16)
 	  | (message[4*offset+2] << 8)
          | (message[4*offset+3] << 0));
  return val;
}

int File_block_num (void) {
  return 1; // the total number of 64-byte blocks
}

int main(void) {
  int i;

  pad();
  SHA256_sha256();

  for (i=0; i<8; i++)
    printf("%08x", SHA256Word_H[i]);
  putchar('\n');
  printf("d7a8fbb307d7809469ca9abcb0082e4f8d5651e46d3cdb762d02d0bf37c9e592\n");  //Expected answer, from Wikipedia.
}

