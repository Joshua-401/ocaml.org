#include <stdio.h>
#include <stdlib.h>
#include <string.h>

extern void SHA256_sha256(void);
extern unsigned int __builtin_read32_reversed(const unsigned int * ptr);


const int len = 100*1024*1024;  //For benchmarking, repeatedly hash 100 MB.
unsigned char *message;

unsigned int File_read(int offset)  {
  unsigned val =
          ( (message[4*offset] << 24)
 	  | (message[4*offset+1] << 16)
 	  | (message[4*offset+2] << 8)
          | (message[4*offset+3] << 0));
  return val;
}

int File_block_num (void) {
  return len/64; // the total number of 64-byte blocks
}

int main(void) {
  message = malloc(len);

  // Do it 10 times, for 1000 MB in total.
  for (int i=0; i<10; i++)
    SHA256_sha256();

}

