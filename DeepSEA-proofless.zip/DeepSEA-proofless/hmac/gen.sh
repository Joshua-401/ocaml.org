#!/bin/sh
edsger_dir=../Edsger
edsger=$edsger_dir/edsger
edsge_gen=$edsger_dir/gen.sh
pg_temp=$edsger_dir/pg_temp
dsfile=sha.ds
dsmod=`echo $dsfile | sed -e 's/\.ds$//g'`

# rm -rf $dsmod
$edsger $dsfile
if [ $? -eq 0 ]; then
    cd $dsmod
    coq_makefile ./*.v -R . $dsmod > Makefile
    cp ../$pg_temp pg
    sed -i 's/^FLAGS=/FLAGS="-R . -as '$dsmod'"/' pg
else
    exit $?
fi
