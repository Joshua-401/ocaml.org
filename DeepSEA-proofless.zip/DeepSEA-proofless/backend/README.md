# Ethereum Compiler Backend

The backend for the ethereum compiler turns an abstract syntax tree similar to Clight into a sequence of ethereum bytecode commands.

# Future Plan

Connect with EVM formalization. This requires many components in remaining compilation passes.

* Combine all methods and functions into a single chunk of code.
    * Remove internal function calls from semantics  (This may be jsut a change in semantic, the syntax already has jumps to labels but we want to get rid of CallState/ReturnSTate)
        * Allow jumps directly across functions
        * Requires assertion that functions begin with their labels
        * Replace Sdone with some of these commands: SWAP, POP, PUSH, RETURN
    * Add Multiplexer so all methods are in one block of code.
        * Recognize and jump to the correct method with signature from calldata
        * Currently not being compiled, although at one point it was part of GlobalenvCompile.v and StmCompile.v
    * Constructor may be in separate block of code   (the evm.v has field for this, it should be used by CREATE.)
        * Currently being compiled but not called in semantics.
        * Constructor should run its own code and return the rest the code for multiplexer, methods, and functions.
        * May require completely separate semantics at each level (different initial/final states?).
* Model Memory, and use it for SHA256 as well as Scallmethod (method args and retvals are put in memory) and Sdone (put the method return values in memory).
    * Eventually it should be a map Int256 -> byte.
* Change storage to a map Int256 -> Int256.  (Currently it's indexed by extended identifies.)
    * One pass should change semantics from ident_ext to actually use hash functions. (Needs some kind of axiom about uniqueness of hash values)
    * Use the final variable allocations and cryptographic assumptions to prove that locations for storage values don't overlap.
    * In the EVM spec labels are indices into the code. Currently, labels are converted to numbers in the pretty-printer, but if we want to integrate with EVM spec we need to do it in Coq.
* Change stack to just a list of Int256's. (Since we need to push labels onto stack, that also requires that conversion. Also, the EVM spec has hashes as numbers, so that also requires work)
* Model calldata as a list of bytes. (Now it's a list of values+the signature. Similar to previous bullet--but maybe we don't care about being given hashes when we are called?)
* Match the "machine environment" with separate maps for each info query, like vctx_balance in evm.v
  (The EVM builtins are scattered in different places in the Yoichi EVM spec, some of them are in the variable state, some in constant state, etc.)
  (So we need to create these from the machine environment, define a relation, or something like that.)
* Split the semantics of callmethod into callstate and returnstate, because that is how the EVM spec does it. 
* Logs
    * Currently Slog statements fail compilation (at the lowest level). Look at how solc compiles them.
* Compose the smallstep semantics proofs together.
    * Each pass has the three proofs needed for simulation proofs. Compose these to prove compilation works.
* Split compound commands (This is currently done in StmCompile.v)
    * Split Sset into swap and pop.
    * Split Sfetchargs into several single fetches


---

# About Data Types and EVM

## Needs Rewrite

First some modifications must be made to Clight because the ethereum virtual machine isn't the same as the environment in which C programs run.

# Reasons for Changes

* EVM has no floating point numbers.
* Word size of the EVM is 256 bits. Most data types are "Value types", meaning they fit in a single word.
* Addresses are 160 bits, and more generally any integer sizes from 8-258 in increments of 8 are allowed, signed and unsigned.
* Contracts have state variables that persist.
* Several new expression types that access properties of the blockchain, like BLOCKHASH and GASLIMIT.
* Some operations are missing from the EVM, like a not-equals primitive.
* C allows crazy use of pointers; EVM restricts memory accesses to fixed-type data structure accesses like arrays, mappings, structs, and value types.
* Instead of stack/heap/data/text segments, EVM has code/calldata/stack/memory/storage for possible locations of variables.
    * Literals are in ROM with the code and pushed to the stack for use.
    * Calldata is a section of read-only memory containing the method signature to call and its arguments.
    * EVM stack contains words for arithmetic operations, arguments, and temps.
    * EVM memory is an array of bytes, with addresses starting at 0; high addresses are expensive.
    * EVM storage is a word-indexed array of words. Using many entries is expensive, and using none gives a bonus.

# Where to Place Data Structures

Typical Solidity locations:

* Mappings must store values in Storage to allow indexing by hash values.
* State variables are in Storage because they must persist.
* Arrays and Structs can either be in Storage or Memory. This is determined by annotations.
* Arrays in Memory have size fixed at creation time (think of Memory as the C-stack).
* Local Value types are on the stack.

Our locations:

* All complex data types are in Storage, including mappings, (fixed-length) arrays, and structs.
* All state variables are in Storage.
* Temps and arguments are on the stack.

# Types for Data Structures

## Primitive types 

Each privitive data type that fits in a single word should be stored in a single word.

For the stack and storage, this is the only way that makes sense.
For memory it only causes minor space inefficiency, in exchange for greatly decreased complexity of operations.
The decreased complexity is because numbers are manipulated on the stack and saved in storage,
so memory is really an intermediate and temporary storage space.

* Boolean
* Integer (int8-int256, uint8-uint256)
* Address
* Enums
* Internal functions (wrapper for jump pointer, with a function signature as part of the type)
* External functions (wrapper for contract address, with a function signature as part of the type)

For each of these types A there is an injective map from A -> uint256,
and this map will be used in all proofs so that essentially all primitive types are 256-bit unsigned integers.

## Compound Types

* Fixed size arrays are fundamentally different from dynamically sized arrays
* byte-arrays and strings are also different, but implemented exactly like variable-sized arrays except with division and modulo built into the operations.
* Location Storage/Memory is part of the type
* The actual value of a complex data structure is a StoragePointer or MemoryPointer, described below.

# Data Storage

## Pointers

Every value referenced by state variables has a "pointer" to access it.

First consider that, recursively, each type has a "size":

* Value types, mappings, and variable-sized arrays have size 1.
* Struct sizes are the sum of their components.
* Fixed-size array size is its length times the size of a single entry.

To find the pointer for a state variable's value, construct it.

* State variables are assigned pointers sequentially, like on the C stack: sum of all sizes before it.
* Struct entries and fixed-size array entries are assigned pointers like in C: base pointer + sum of sizes before entry.
* Mapping entries are calculated as hash(key . base pointer), where "." denotes concatenation of words.
* Variable-sized array length is at the base pointer and entries are at hash(index . base pointer).

Example code

```
contract C {
    struct Container {
        uint thing;
        mapping (uint => uint[5]) arrayMap;
    }
    Container[4] containers;
    function functionName() {
        containers[2].arrayMap[200][3] = 15;
    }
}
```

Pointer values in example.

* `containers`: 0x0
* `containers[2]`: 0x4
* `containers[2].arrayMap`: 0x5
* `containers[2].arrayMap[200]`: hash(0xc8 . 0x5)
* `containers[2].arrayMap[200][3]`: hash(0xc8 . 0x5) + 0x3

This will require implementing Storage in the memory model as being indexed by a new type "StoragePointer".

See Pointers.v for the implementation.

The StoragePointer has a more restricted cousin, MemoryPointer, which doesn't do hashing.
As a result, MemoryPointers are bounded by the start of the compiled function's "stack frame"
and the compile-time-known size of the data structures.
This should allow proofs that contracts don't use excessive memory.

## Memory Isolation

The high level memory model contains the state of the contract:
a list of data structures in Storage and Memory, and...

# Values

The stack, memory, and storage must store many kinds of things, conceptually.
Even though each is represented by a 256-bit integer on the real EVM,
they should be kept semantically separate.

* Integer - raw 256-bit word
* Address - argument to CALL and similar commands
* StoragePointer - address to be used as an index into storage
* MemoryPointer - offset to be used as an index into memory
* MemorySize - size to be used for memory access (used by SHA3, RETURN, CALL, etc.)
* Label - argument to JUMP and JUMPI

# Output Format

The primary output should be EVM assembly, not bytecode. A final pass can then assemble the code easily.
Assembly has many advantages over bytecode for internal computation.
I will list here the details of the final assembling,
which should make it clear why we don't want to deal with bytecode too soon.

* Labels must be converted into absolute addresses, which requires a global ordering of the output and determining how many bytes are used by each segment.
* PUSH commands precede their arguments and must count the bytes in their arguments.

# Compilation Phases

In order to simplify logic and help with proving later, I break the compiler into phases.

* Expand var/tempvar rvalues to stack/memory/storage dereferences, by determining where the variables are.
* Expand lvalues to stack/memory/storage dereferences, by determining where the variable should be assigned.
* Remove operations like bitshift and <= and != for which the EVM does not have primitives, by replacing with equivalents.
* Divide up function calls into external or internal or primitives (maybe push this all the way up)
* Compile conditionals and fun calls to labels and gotos.


* Look at what DeepSEA compiles to. If doesn't exist, like sswitch, label, goto, delete from clight.
* Add Gotos and Labels to a new intermediate language.

* Do not implement local variables. Complex data types are all globals. Temps can all be stored on the stack, they're all simple. No call stack.

# Function compilation

* A few things to remember about how functions are compiled.
* The whole thing is turned into a flow graph, and compiled as such, a labels and jump between each source command.
* Each function ends by jumping to either a Sdone or an Srevert,
    * An Srevert corresponds to a REVERT command in the EVM
    * An Sdone corresponds to function cleanup and returning of a pushed value.

# Types

The only types that have significance are
* Tstruct (fields may be arrays or other structs)
* Tarray (can be of arrays or structs)
* Tvoid (used for functions that don't return anything)

All other types are treated exactly the same. You can give a hash table type Tint and it will work.

