
type builtin0 =
| Baddress
| Borigin
| Bcaller
| Bcallvalue
| Bcoinbase
| Btimestamp
| Bnumber

type builtin1 =
| Bbalance
| Bblockhash
