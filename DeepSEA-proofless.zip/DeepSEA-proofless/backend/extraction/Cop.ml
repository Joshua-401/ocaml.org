
type unary_operation =
| Onotbool
| Onotint
| Oneg
| Osha_1

type binary_operation =
| Oadd
| Osub
| Omul
| Odiv
| Omod
| Oexp
| Oand
| Oor
| Oxor
| Oshl
| Oshr
| Oeq
| One
| Olt
| Ogt
| Ole
| Oge
| Osha_2
