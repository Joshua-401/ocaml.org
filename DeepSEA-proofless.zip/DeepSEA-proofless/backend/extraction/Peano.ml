
type __ = Obj.t

type ge = __
