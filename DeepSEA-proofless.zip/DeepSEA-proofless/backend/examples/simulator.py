
import sys, os
import hashlib

DEBUG = '-q' not in sys.argv


class EVM(object):
    def __init__(self, code):
        self.code = code
        self.storage = dict()

    def label_to_pc(self, label):
        search_label = "0x%x:" % label
        if DEBUG:
            print "searching for label", search_label
        for lineno, line in enumerate(self.code):
            cmd = line.split(';')[0].strip()
            if cmd == search_label:
                if DEBUG:
                    print "found label", line
                return lineno
        raise Exception("can't find label", label, search_label)

    def jump(self, label):
        self.pc = self.label_to_pc(label)

    def runcmd(self, cmd):
        if DEBUG:
            print 'running command {}'.format(cmd)
        cmd = cmd.split(';')[0].strip()  # remove comments and whitespace
        if len(cmd) == 0:
            return
        if cmd.startswith("push"):
            self.stack.append(int(cmd.split(" ")[1], 0))
        elif cmd.startswith("push_label"):
            self.stack.append(int(cmd.split(" ")[1], 0))
        elif cmd.startswith("swap"):
            index = int(cmd.split(" ")[1]) + 1
            temp = self.stack[-index]
            self.stack[-index] = self.stack[-1]
            self.stack[-1] = temp
        elif cmd.startswith("dup"):
            index = int(cmd.split(" ")[1])
            self.stack.append(self.stack[-index])

        elif cmd == "jump":
            self.jump(self.stack.pop())
        elif cmd == "jumpi":
            j = self.stack.pop()
            e = self.stack.pop()
            if e:
                self.jump(j)

        elif cmd == 'add':
            self.stack.append(self.stack.pop() + self.stack.pop())
        elif cmd == 'sub':
            self.stack.append(self.stack.pop() - self.stack.pop())
        elif cmd == 'div' or cmd == 'sdiv':
            self.stack.append(self.stack.pop() / self.stack.pop())
        elif cmd == 'mul':
            self.stack.append(self.stack.pop() * self.stack.pop())
        elif cmd == 'mod' or cmd == 'smod':
            self.stack.append(self.stack.pop() % self.stack.pop())
        elif cmd == 'exp':
            self.stack.append(self.stack.pop() ** self.stack.pop())
        elif cmd == 'lt' or cmd == 'slt':
            self.stack.append(int(self.stack.pop() < self.stack.pop()))
        elif cmd == 'gt' or cmd == 'sgt':
            self.stack.append(int(self.stack.pop() > self.stack.pop()))
        elif cmd == 'eq':
            self.stack.append(int(self.stack.pop() == self.stack.pop()))
        elif cmd == 'iszero':
            self.stack.append(int(not self.stack.pop()))
        elif cmd == 'and':
            self.stack.append(self.stack.pop() & self.stack.pop())
        elif cmd == 'or':
            self.stack.append(self.stack.pop() | self.stack.pop())
        elif cmd == 'xor':
            self.stack.append(self.stack.pop() ^ self.stack.pop())
        elif cmd == 'not':
            self.stack.append(~self.stack.pop())

        elif cmd == 'sha3':
            start = self.stack.pop() / 32
            length = self.stack.pop() / 32
            m = hashlib.sha256()
            while length > 0:
                val = '%064x' % self.memory[start]
                if DEBUG:
                    print val
                m.update(val)
                start += 1
                length -= 1
            if DEBUG:
                print 'hash digest is {}'.format(m.hexdigest())
            self.stack.append(int(m.hexdigest(), 16))
        
        elif cmd == 'caller':
            caller = int(raw_input('CALLER (address): '))
            self.stack.append(self.caller)
        elif cmd == 'balance':
            balance = int(raw_input('BALANCE({}): '.format(self.stack.pop())))
            self.stack.append(balance)
        elif cmd == 'callvalue':
            callvalue = int(raw_input('CALLVALUE: '))
            self.stack.append(callvalue)
        elif cmd == 'calldataload':
            calldataload = int(raw_input('CALLDATALOAD({}): '.format(self.stack.pop())))
            self.stack.append(calldataload)

        elif cmd == 'pop':
            self.stack.pop()
        elif cmd == 'mload':
            self.stack.append(self.memory[self.stack.pop() / 32])
        elif cmd == 'mstore':
            where = self.stack.pop() / 32
            what = self.stack.pop()
            while len(self.memory) <= where:
                self.memory.append(0)
            self.memory[where] = what
        elif cmd == 'sload':
            where = self.stack.pop()
            if not self.storage.has_key(where):
                self.storage[where] = 0
            self.stack.append(self.storage[where])
        elif cmd == 'sstore':
            where = self.stack.pop()
            self.storage[where] = self.stack.pop()
        elif cmd.endswith(':'):
            pass
        elif cmd == 'return':
            where = self.stack.pop() / 32
            length_raw = self.stack.pop()
            if length_raw == 'CODESIZE':
                print 'RETURN code:'
                print '-' * 80
                print '\n'.join(self.memory[where])
                print '-' * 80
            else:
                length = length_raw / 32
                print 'returning {} values:'.format(length)
                while length > 0:
                    print self.memory[where]
                    where += 1
                    length -= 1
        elif cmd == 'revert':
            self.storage = self.saved_storage
            where = self.stack.pop() / 32
            length = self.stack.pop() / 32
            print 'reverting with {} values:'.format(length)
            while length > 0:
                print self.memory[where]
                where += 1
                length -= 1
        elif cmd == 'codesize':
            # hack to return the assembly
            self.stack.append('CODESIZE')
        elif cmd == 'codecopy':
            dest = self.stack.pop() / 32  # index in memory
            while len(self.memory) <= dest:
                self.memory.append(0)
            where = self.stack.pop()  # a label in the code
            start_index = self.label_to_pc(where)
            length = self.stack.pop()  # should be CODESIZE
            if length != 'CODESIZE':
                raise Exception('Expected to get all the rest of the code')
            # not exactly right, because it's assembly, not bytecode
            codecopy = self.code[start_index:]
            # as long as we're not exactly right, might as well make it readable
            # by putting the whole list in one memory slot
            self.memory[dest] = codecopy
        else:
            raise Exception('unrecognized command', cmd)

        if DEBUG:
            print self.stack

    def runloop(self):
        while True:
            assert self.pc < len(self.code)
            cmd = self.code[self.pc]
            self.runcmd(cmd)
            self.pc += 1
            if cmd == "return" or cmd == 'revert':
                break

    def run(self):
        self.saved_storage = self.storage.copy()
        self.pc = 0
        self.stack = []
        self.memory = []
        self.runloop()
        if DEBUG:
            print 'Storage: ', self.storage


evm_filename = sys.argv[1]

commands = []

with open(evm_filename) as f:
    for line in f:
        commands.append(line.strip())

evm = EVM(commands)
while True:
    if DEBUG:
        print 'Beginning simulation of {}'.format(evm_filename)
    evm.run()
    if raw_input('Run again? (y/n) ').lower() != 'y':
        break


