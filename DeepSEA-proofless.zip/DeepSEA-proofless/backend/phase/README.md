# Backend Compilation Phases

Each subdirectory here is a phase of compilation, including language definition, semantics (possibly in the same file as definition), generation from previous language, and proof of smallstep semantic equivalence.

- MiniC
- Clike
- Cgraph
- Cbasic
- Clinear
- Clabeled
- Stacked
- Expressionless
- Methodical
